public abstract class CaseSpé extends CaseAbs{
    private int argent ;

    public CaseSpé(Integer id) {
        super(id);


    }




}