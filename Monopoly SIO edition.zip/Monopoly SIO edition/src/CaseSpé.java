public abstract class CaseSpé extends CaseAbs{


    public CaseSpé(Integer id,Integer joueurScase) {
        super(id,joueurScase);


    }

    public void méthodeX() {

    }




}