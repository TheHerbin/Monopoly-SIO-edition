public class  CaseDebut extends CaseSpé{
    private int argent ;

    public CaseDebut(Integer id) {
        super(id);
        this.argent = 200;

    }

    @Override
    public void méthodeX() {

    }


}

