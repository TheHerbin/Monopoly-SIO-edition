public class  CaseDebut extends CaseSpé{
    private int argent ;

    public CaseDebut(Integer id,Integer joueurScase) {
        super(id,joueurScase);

        this.argent = 200;

    }

    @Override
    public void méthodeX() {



    }


}

