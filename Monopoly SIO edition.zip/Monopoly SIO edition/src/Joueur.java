public class Joueur {

    private int argent;
    private double moyenne;
    private String pion;
    private int id;


    public Joueur(int argent, double moyenne, String pion,int id) {
        this.argent = argent;
        this.moyenne = moyenne;
        this.pion = pion;
        this.id = id ;
    }

    public int getArgent() {
        return argent;
    }

    public void setArgent(int argent) {
        this.argent = argent;
    }

    public double getMoyenne() {
        return moyenne;
    }

    public void setMoyenne(double moyenne) {
        this.moyenne = moyenne;
    }

    public String getPion() {
        return pion;
    }

    public void setPion(String pion) {
        this.pion = pion;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
