public class Case {
    private String prof;
    private double coeff;
    private String propriétaire;
    private double pAchat;
    private int typeC;


    //Constructeur ----------------------------------------------------------------------

    public Case(int typeC) {
        this.typeC = typeC;
        TypeCase();
    }


    //Accesseurs ------------------------------------------------------------------------


    public String getProf() {
        return prof;
    }

    public void setProf(String prof) {
        this.prof = prof;
    }

    public double getCoeff() {
        return coeff;
    }

    public void setCoeff(double coeff) {
        this.coeff = coeff;
    }

    public String getPropriétaire() {
        return propriétaire;
    }

    public void setPropriétaire(String propriétaire) {
        this.propriétaire = propriétaire;
    }

    public double getpAchat() {
        return pAchat;
    }

    public void setpAchat(double pAchat) {
        this.pAchat = pAchat;
    }

    public int getTypeC() {
        return typeC;
    }

    public void setTypeC(int typeC) {
        this.typeC = typeC;
    }

    //Fonctions-----------------------------------------------------------------------------------------


    public void TypeCase(){
        switch (getTypeC()){
            case 1:
                setCoeff(1);
                setpAchat(50);
                break;
            case 2:

               
                break;

        }


    }
    // faire en sorte d'instancier les actions des cases en fonction du chiffre écrit ...




}
