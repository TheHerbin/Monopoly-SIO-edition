public class Case {
    private String prof;
    private double coeff;
    private String propriétaire;
    private double pAchat;

    //Constructeur ----------------------------------------------------------------------

    public Case( double coeff, double pAchat) {
        this.coeff = coeff;
        this.pAchat = pAchat;
    }


    //Accesseurs ------------------------------------------------------------------------


    public String getProf() {
        return prof;
    }

    public void setProf(String prof) {
        this.prof = prof;
    }

    public double getCoeff() {
        return coeff;
    }

    public void setCoeff(double coeff) {
        this.coeff = coeff;
    }

    public String getPropriétaire() {
        return propriétaire;
    }

    public void setPropriétaire(String propriétaire) {
        this.propriétaire = propriétaire;
    }

    public double getpAchat() {
        return pAchat;
    }

    public void setpAchat(double pAchat) {
        this.pAchat = pAchat;
    }




    //Fonctions-----------------------------------------------------------------------------------------


}
