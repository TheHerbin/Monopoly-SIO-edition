


import java.util.ArrayList;
import java.util.Scanner;

public class mainActivity {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Fonctions fonctions = new Fonctions();
        ArrayList<Joueur> Joueurs = new ArrayList<>();
       ArrayList<Case> Plateau = new ArrayList<>();
       double prix = 50;
       for (var i=1;i<=4;i++) {

           Plateau.set(i,new Case(1,prix));
           prix= prix*1.10;
       }
        for (var i=6;i<=9;i++) {
            Plateau.set(i,new Case(1,prix));
            prix= prix*1.10;
        }
        for (var i=11;i<=14;i++) {
            Plateau.set(i,new Case(1,prix));
            prix= prix*1.10;
        }
        for (var i=14;i<=19;i++) {
            Plateau.set(i,new Case(1,prix));
            prix= prix*1.10;
        }
        System.out.println(Joueurs.get(4));

        int tour = 0;

        int choixI = Integer.parseInt(ChoixnbrJoueur(Joueurs));
        fonctions.setChoixI(choixI);
        System.out.println("C'est au joueur "+fonctions.determinejoueur()+" de jouer !");
            while(Joueurs.size()>1){
                System.out.println("C'est au joueur "+fonctions.determinejoueur()+" de jouer !");




                tour = tour+1;
                fonctions.setTour(tour);
            }



    }



        //Choix nbr Joueurs au début

    public static String ChoixnbrJoueur(ArrayList Joueurs){
        Scanner input = new Scanner(System.in);
        String choix = "";
        System.out.println("Combien de joueur vont jouer ???de 2 à 4 max");
        choix = input.next();
        String pion;
        switch (choix){
            case "2":
                System.out.println("Joueur 1 , Quel pion voulez vous choisir ?? tapez son nom");
                pion = input.next();
                    Joueurs.add(new Joueur( 200,10.00,pion,1));
                System.out.println("Joueur 2 , Quel pion voulez vous choisir ?? tapez son nom");
                 pion = input.next();
                Joueurs.add(new Joueur( 200,10.00,pion,2));

                break;
            case "3":
                System.out.println("Joueur 1 , Quel pion voulez vous choisir ?? tapez son nom");
                pion = input.next();
                Joueurs.add(new Joueur( 200,10.00,pion,1));
                System.out.println("Joueur 2 , Quel pion voulez vous choisir ?? tapez son nom");
                pion = input.next();
                Joueurs.add(new Joueur( 200,10.00,pion,2));
                System.out.println("Joueur 3 , Quel pion voulez vous choisir ?? tapez son nom");
                pion = input.next();
                Joueurs.add(new Joueur( 200,10.00,pion,3));

                break;
            case "4":
                System.out.println("Joueur 1 , Quel pion voulez vous choisir ?? tapez son nom");
                pion = input.next();
                Joueurs.add(new Joueur( 200,10.00,pion,1));
                System.out.println("Joueur 2 , Quel pion voulez vous choisir ?? tapez son nom");
                pion = input.next();
                Joueurs.add(new Joueur( 200,10.00,pion,2));
                System.out.println("Joueur 3 , Quel pion voulez vous choisir ?? tapez son nom");
                pion = input.next();
                Joueurs.add(new Joueur( 200,10.00,pion,3));
                System.out.println("Joueur 4 , Quel pion voulez vous choisir ?? tapez son nom");
                pion = input.next();
                Joueurs.add(new Joueur( 200,10.00,pion,4));

                break;
            default :
                System.out.println("Ce n'est pas une réponse adaptée...");
                ChoixnbrJoueur(Joueurs);
                break;



        }
        return choix;
    }

}
