import java.util.ArrayList;
import java.util.Random;

public class Fonctions {
   private int tour ;
   private int choixI;
   private ArrayList<Joueur> Joueurs;



   //Constructeur : -----------------------------------------------------------------

    public Fonctions() {

    }


    //Accesseurs :-------------------------------------------------------------------


    public int getTour() {
        return tour;
    }

    public void setTour(int tour) {
        this.tour = tour;
    }

    public int getChoixI() {
        return choixI;
    }

    public void setChoixI(int choixI) {
        this.choixI = choixI;
    }

    public ArrayList<Joueur> getJoueurs() {
        return Joueurs;
    }

    public void setJoueurs(ArrayList<Joueur> joueurs) {
        Joueurs = joueurs;
    }

    //Fonctions ----------------------------------------------------------------
    public int LancerDé(){ //tire un rdm et le retourne

    Random obj = new Random();
    int rdm = obj.nextInt(7);
    System.out.println(rdm);
    return rdm ;

}

    public int determinejoueur() {//détermine le joueur qui doit jouer et le retourne
        int joueur = this.tour % getChoixI() ;
        joueur = joueur +1;
        return joueur;
    }

    public void eliminejoueur(int tourjoueur){
        getJoueurs();


        if (tourjoueur==5||tourjoueur==10||tourjoueur==15){
            System.out.println("élimination");
            setTour(tour+1);
        }

    }










}
