public abstract class CaseAbs {
  protected Integer id;

  //Constructeur :

    public CaseAbs(Integer id) {
        this.id = id;
    }

    //Accesseurs


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    //méthodes





}
