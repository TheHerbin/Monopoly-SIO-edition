public abstract class CaseAbs {         //équivalent de Case
  protected Integer id;
  protected Integer joueurScase;
  //Constructeur :

    public CaseAbs(Integer id,Integer joueurScase) {
        this.id = id;
        this.joueurScase = joueurScase;

    }



    //Accesseurs


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getJoueurScase() {
        return joueurScase;
    }

    public void setJoueurScase(Integer joueurScase) {
        this.joueurScase = joueurScase;
    }

    //méthodes





}
